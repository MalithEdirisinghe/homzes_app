// import 'dart:async';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import '../../../data/repositories/property_repository.dart';
// import 'properties_event.dart';
// import 'properties_state.dart';
// import '../../../data/models/property.dart';

// class PropertiesBloc extends Bloc<PropertiesEvent, PropertiesState> {
//   final PropertyRepository _propertyRepository;
//   StreamSubscription? _featuredPropertiesSubscription;
//   StreamSubscription? _newOfferPropertiesSubscription;
//   StreamSubscription? _popularRentPropertiesSubscription;

//   PropertiesBloc(this._propertyRepository) : super(PropertiesLoaded(
//   featuredProperties: [
//     Property(
//       id: '1',
//       title: 'Modern Luxury Villa',
//       imageUrl: 'assets/images/house1.jpg',
//       location: 'Los Angeles, CA',
//       price: 1250,
//       numberOfBeds: 3, 
//       numberOfBathrooms: 2,
//       rating: 4.9,
//       reviewCount: 29,
//       isFeatured: true,
//       isNewOffer: false,
//       createdAt: DateTime.now(),
//     ),
//     Property(
//       id: '2',
//       title: 'Beachfront Condo',
//       imageUrl: 'assets/images/house4.jpg',
//       location: 'San Diego, CA',
//       price: 980,
//       numberOfBeds: 2,
//       numberOfBathrooms: 2,
//       rating: 4.7,
//       reviewCount: 15,
//       isFeatured: true,
//       isNewOffer: false,
//       createdAt: DateTime.now(),
//     ),
//   ],
//   newOfferProperties: [
//     Property(
//       id: '3',
//       title: 'Contemporary White House',
//       imageUrl: 'assets/images/house2.jpg',
//       location: 'Miami, FL',
//       price: 1430,
//       numberOfBeds: 2,
//       numberOfBathrooms: 2,
//       rating: 4.7,
//       reviewCount: 18,
//       isFeatured: false,
//       isNewOffer: true,
//       createdAt: DateTime.now(),
//     ),
//     Property(
//       id: '4',
//       title: 'Downtown Loft',
//       imageUrl: 'assets/images/house1.jpg',
//       location: 'New York, NY',
//       price: 2100,
//       numberOfBeds: 1,
//       numberOfBathrooms: 1,
//       rating: 4.5,
//       reviewCount: 22,
//       isFeatured: false,
//       isNewOffer: true,
//       createdAt: DateTime.now(),
//     ),
//   ],
//   popularRentProperties: [
//     Property(
//       id: '5',
//       title: 'Craftsman Style Home',
//       imageUrl: 'assets/images/house3.jpg',
//       location: 'Seattle, WA',
//       price: 750,
//       numberOfBeds: 4,
//       numberOfBathrooms: 2,
//       rating: 4.8,
//       reviewCount: 24,
//       isFeatured: true,
//       isNewOffer: false,
//       createdAt: DateTime.now(),
//     ),
//     Property(
//       id: '6',
//       title: 'Modern Glass Residence',
//       imageUrl: 'assets/images/house4.jpg',
//       location: 'Austin, TX',
//       price: 1580,
//       numberOfBeds: 3,
//       numberOfBathrooms: 2,
//       rating: 4.5,
//       reviewCount: 12,
//       isFeatured: true,
//       isNewOffer: false,
//       createdAt: DateTime.now(),
//     ),
//   ],
// )) {
//   on<LoadFeaturedProperties>(_onLoadFeaturedProperties);
//   on<LoadNewOfferProperties>(_onLoadNewOfferProperties);
//   on<LoadPopularRentProperties>(_onLoadPopularRentProperties);
//   on<AddSampleProperties>(_onAddSampleProperties);
  
//   // We're not auto-triggering these events since we're pre-loading data
//   // add(LoadFeaturedProperties());
//   // add(LoadNewOfferProperties());
//   // add(LoadPopularRentProperties());
// }

//   void _onLoadFeaturedProperties(
//   LoadFeaturedProperties event,
//   Emitter<PropertiesState> emit,
// ) {
//   print("Loading featured properties...");
//   emit(PropertiesLoading());  // Add this line to explicitly emit loading state
  
//   _featuredPropertiesSubscription?.cancel();
//   _featuredPropertiesSubscription = _propertyRepository.getFeaturedProperties().listen(
//     (properties) {
//       print("Received featured properties: ${properties.length}");
//       // Rest of your code...
//     },
//     onError: (error) {
//       print("Error loading featured properties: $error");
//       emit(PropertiesError(error.toString()));
//     },
//   );
// }

//   void _onLoadNewOfferProperties(
//     LoadNewOfferProperties event,
//     Emitter<PropertiesState> emit,
//   ) {
//     _newOfferPropertiesSubscription?.cancel();
//     _newOfferPropertiesSubscription = _propertyRepository.getNewOfferProperties().listen(
//       (properties) {
//         if (state is PropertiesLoaded) {
//           emit((state as PropertiesLoaded).copyWith(newOfferProperties: properties));
//         } else {
//           emit(PropertiesLoaded(newOfferProperties: properties));
//         }
//       },
//       onError: (error) {
//         emit(PropertiesError(error.toString()));
//       },
//     );
//   }

//   void _onLoadPopularRentProperties(
//     LoadPopularRentProperties event,
//     Emitter<PropertiesState> emit,
//   ) {
//     _popularRentPropertiesSubscription?.cancel();
//     _popularRentPropertiesSubscription = _propertyRepository.getPopularRentProperties().listen(
//       (properties) {
//         if (state is PropertiesLoaded) {
//           emit((state as PropertiesLoaded).copyWith(popularRentProperties: properties));
//         } else {
//           emit(PropertiesLoaded(popularRentProperties: properties));
//         }
//       },
//       onError: (error) {
//         emit(PropertiesError(error.toString()));
//       },
//     );
//   }

//   void _onAddSampleProperties(
//     AddSampleProperties event,
//     Emitter<PropertiesState> emit,
//   ) async {
//     try {
//       await _propertyRepository.addSampleData();
//     } catch (e) {
//       emit(PropertiesError(e.toString()));
//     }
//   }

//   @override
//   Future<void> close() {
//     _featuredPropertiesSubscription?.cancel();
//     _newOfferPropertiesSubscription?.cancel();
//     _popularRentPropertiesSubscription?.cancel();
//     return super.close();
//   }
// }

import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../data/repositories/property_repository.dart';
import 'properties_event.dart';
import 'properties_state.dart';
import '../../../data/models/property.dart';

class PropertiesBloc extends Bloc<PropertiesEvent, PropertiesState> {
  final PropertyRepository _propertyRepository;
  StreamSubscription? _featuredPropertiesSubscription;
  StreamSubscription? _newOfferPropertiesSubscription;
  StreamSubscription? _popularRentPropertiesSubscription;

  PropertiesBloc(this._propertyRepository) : super(PropertiesInitial()) {
    on<LoadFeaturedProperties>(_onLoadFeaturedProperties);
    on<LoadNewOfferProperties>(_onLoadNewOfferProperties);
    on<LoadPopularRentProperties>(_onLoadPopularRentProperties);
    on<AddSampleProperties>(_onAddSampleProperties);
    
    // Automatically load data when bloc is created
    add(LoadFeaturedProperties());
    add(LoadNewOfferProperties());
    add(LoadPopularRentProperties());
  }

  void _onLoadFeaturedProperties(
    LoadFeaturedProperties event,
    Emitter<PropertiesState> emit,
  ) {
    print("Loading featured properties from Firebase...");
    
    // Only emit loading state if we're not already in a loaded state
    if (!(state is PropertiesLoaded)) {
      emit(PropertiesLoading());
    }
    
    _featuredPropertiesSubscription?.cancel();
    _featuredPropertiesSubscription = _propertyRepository.getFeaturedProperties().listen(
      (properties) {
        print("Received featured properties: ${properties.length}");
        
        // Handle the received properties
        if (state is PropertiesLoaded) {
          emit((state as PropertiesLoaded).copyWith(featuredProperties: properties));
        } else {
          emit(PropertiesLoaded(featuredProperties: properties));
        }
      },
      onError: (error) {
        print("Error loading featured properties: $error");
        
        // Emit error state only if we're not already in a loaded state
        if (!(state is PropertiesLoaded)) {
          emit(PropertiesError(error.toString()));
        }
      },
    );
  }

  void _onLoadNewOfferProperties(
    LoadNewOfferProperties event,
    Emitter<PropertiesState> emit,
  ) {
    print("Loading new offer properties from Firebase...");
    
    _newOfferPropertiesSubscription?.cancel();
    _newOfferPropertiesSubscription = _propertyRepository.getNewOfferProperties().listen(
      (properties) {
        print("Received new offer properties: ${properties.length}");
        
        // Update state with new properties
        if (state is PropertiesLoaded) {
          emit((state as PropertiesLoaded).copyWith(newOfferProperties: properties));
        } else {
          emit(PropertiesLoaded(newOfferProperties: properties));
        }
      },
      onError: (error) {
        print("Error loading new offer properties: $error");
        
        // Only emit error if we're not in a loaded state
        if (!(state is PropertiesLoaded)) {
          emit(PropertiesError(error.toString()));
        }
      },
    );
  }

  void _onLoadPopularRentProperties(
    LoadPopularRentProperties event,
    Emitter<PropertiesState> emit,
  ) {
    print("Loading popular rent properties from Firebase...");
    
    _popularRentPropertiesSubscription?.cancel();
    _popularRentPropertiesSubscription = _propertyRepository.getPopularRentProperties().listen(
      (properties) {
        print("Received popular rent properties: ${properties.length}");
        
        // Update state with popular rent properties
        if (state is PropertiesLoaded) {
          emit((state as PropertiesLoaded).copyWith(popularRentProperties: properties));
        } else {
          emit(PropertiesLoaded(popularRentProperties: properties));
        }
      },
      onError: (error) {
        print("Error loading popular rent properties: $error");
        
        // Only emit error if we're not in a loaded state
        if (!(state is PropertiesLoaded)) {
          emit(PropertiesError(error.toString()));
        }
      },
    );
  }

  void _onAddSampleProperties(
    AddSampleProperties event,
    Emitter<PropertiesState> emit,
  ) async {
    try {
      print("Adding sample properties to Firebase...");
      emit(PropertiesLoading());
      
      // Upload and add data to Firestore
      await _propertyRepository.addSampleData();
      print("Sample data added successfully to Firebase");
      
      // Reload data from Firebase
      add(LoadFeaturedProperties());
      add(LoadNewOfferProperties());
      add(LoadPopularRentProperties());
      
    } catch (e) {
      print("Error adding sample properties: $e");
      emit(PropertiesError(e.toString()));
    }
  }

  @override
  Future<void> close() {
    // Clean up subscriptions
    _featuredPropertiesSubscription?.cancel();
    _newOfferPropertiesSubscription?.cancel();
    _popularRentPropertiesSubscription?.cancel();
    return super.close();
  }
}