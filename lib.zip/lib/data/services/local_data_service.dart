import '../models/property.dart';

class LocalDataService {
  List<Property> getSampleFeaturedProperties() {
    return [
      Property(
        id: '1',
        title: 'Modern Luxury Villa',
        imageUrl: 'assets/images/house1.jpg',
        location: 'Los Angeles, CA',
        price: 1250,
        numberOfBeds: 3,
        numberOfBathrooms: 2,
        rating: 4.9,
        reviewCount: 29,
        isFeatured: true,
        isNewOffer: true,
        createdAt: DateTime.now(),
      ),
      Property(
        id: '2',
        title: 'Beachfront Condo',
        imageUrl: 'assets/images/house4.jpg',
        location: 'San Diego, CA',
        price: 980,
        numberOfBeds: 2,
        numberOfBathrooms: 2,
        rating: 4.7,
        reviewCount: 15,
        isFeatured: true,
        isNewOffer: false,
        createdAt: DateTime.now(),
      ),
    ];
  }
  
  List<Property> getSampleNewOfferProperties() {
    return [
      Property(
        id: '3',
        title: 'Contemporary White House',
        imageUrl: 'assets/images/house2.jpg',
        location: 'Miami, FL',
        price: 1430,
        numberOfBeds: 2,
        numberOfBathrooms: 2,
        rating: 4.7,
        reviewCount: 18,
        isFeatured: false,
        isNewOffer: true,
        createdAt: DateTime.now(),
      ),
      Property(
        id: '4',
        title: 'Downtown Loft',
        imageUrl: 'assets/images/house1.jpg',
        location: 'New York, NY',
        price: 2100,
        numberOfBeds: 1,
        numberOfBathrooms: 1,
        rating: 4.5,
        reviewCount: 22,
        isFeatured: false,
        isNewOffer: true,
        createdAt: DateTime.now(),
      ),
    ];
  }

  List<Property> getSamplePopularRentProperties() {
    return [
      Property(
        id: '5',
        title: 'Craftsman Style Home',
        imageUrl: 'assets/images/house3.jpg',
        location: 'Seattle, WA',
        price: 750,
        numberOfBeds: 4,
        numberOfBathrooms: 2,
        rating: 4.8,
        reviewCount: 24,
        isFeatured: true,
        isNewOffer: false,
        createdAt: DateTime.now(),
      ),
      Property(
        id: '6',
        title: 'Modern Glass Residence',
        imageUrl: 'assets/images/house4.jpg',
        location: 'Austin, TX',
        price: 1580,
        numberOfBeds: 3,
        numberOfBathrooms: 2,
        rating: 4.5,
        reviewCount: 12,
        isFeatured: true,
        isNewOffer: false,
        createdAt: DateTime.now(),
      ),
      Property(
        id: '7',
        title: 'Luxury Penthouse Suite',
        imageUrl: 'assets/images/house1.jpg',
        location: 'Chicago, IL',
        price: 2150,
        numberOfBeds: 3,
        numberOfBathrooms: 3,
        rating: 4.9,
        reviewCount: 31,
        isFeatured: false,
        isNewOffer: false,
        createdAt: DateTime.now(),
      ),
    ];
  }
}