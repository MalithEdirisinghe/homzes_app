// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import '../../routes.dart';
// import '../../logic/blocs/properties/properties_bloc.dart';
// import '../../logic/blocs/properties/properties_state.dart';
// import '../../logic/blocs/properties/properties_event.dart';
// import '../widgets/search_bar.dart';
// import '../widgets/property_card.dart';

// class CatalogScreen extends StatelessWidget {
//   const CatalogScreen({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFFEEF5B1),
//       body: SafeArea(
//         child: BlocBuilder<PropertiesBloc, PropertiesState>(
//           builder: (context, state) {
//   if (state is PropertiesInitial) {
//     // Dispatch events to load properties
//     context.read<PropertiesBloc>().add(LoadFeaturedProperties());
//     context.read<PropertiesBloc>().add(LoadNewOfferProperties());
//     return const Center(child: CircularProgressIndicator());
//   } else if (state is PropertiesLoading) {
//     return const Center(child: CircularProgressIndicator());
//   } else if (state is PropertiesError) {
//     // Add error handling with a retry button
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text("Error: ${state.message}"),
//           ElevatedButton(
//             onPressed: () {
//               context.read<PropertiesBloc>().add(LoadFeaturedProperties());
//               context.read<PropertiesBloc>().add(LoadNewOfferProperties());
//             },
//             child: const Text("Retry"),
//           ),
//         ],
//       ),
//     );
//   } else if (state is PropertiesLoaded) {
//               return Column(
//                 children: [
//                   const SizedBox(height: 16),
                  
//                   // App Bar
//                   Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 20),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         GestureDetector(
//                           onTap: () {
//                             // Open drawer or menu
//                           },
//                           child: Container(
//                             width: 44,
//                             height: 44,
//                             decoration: BoxDecoration(
//                               color: Colors.white.withOpacity(0.8),
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: const Icon(
//                               Icons.menu,
//                               color: Colors.black87,
//                             ),
//                           ),
//                         ),
//                         const Row(
//                           children: [
//                             Text(
//                               'Hi, Stanislav',
//                               style: TextStyle(
//                                 fontSize: 18,
//                                 fontWeight: FontWeight.w600,
//                               ),
//                             ),
//                             SizedBox(width: 12),
//                             CircleAvatar(
//                               radius: 20,
//                               backgroundColor: Colors.grey,
//                               child: Text(
//                                 'S',
//                                 style: TextStyle(
//                                   color: Colors.white,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
                  
//                   const SizedBox(height: 24),
                  
//                   // Search Bar
//                   const CustomSearchBar(),
                  
//                   const SizedBox(height: 24),
                  
//                   // Content
//                   Expanded(
//                     child: Container(
//                       decoration: const BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.only(
//                           topLeft: Radius.circular(32),
//                           topRight: Radius.circular(32),
//                         ),
//                       ),
//                       child: SingleChildScrollView(
//                         padding: const EdgeInsets.only(top: 24, bottom: 16),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             // Featured Section
//                             Padding(
//                               padding: const EdgeInsets.symmetric(horizontal: 20),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   const Text(
//                                     'Featured',
//                                     style: TextStyle(
//                                       fontSize: 20,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                   ),
//                                   TextButton(
//                                     onPressed: () {
//                                       Navigator.pushNamed(context, AppRouter.popularScreen);
//                                     },
//                                     child: const Text(
//                                       'View all',
//                                       style: TextStyle(
//                                         color: Colors.black54,
//                                         fontSize: 14,
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
                            
//                             const SizedBox(height: 16),
                            
//                             // Featured Properties List
//                             SizedBox(
//                               height: 250,
//                               child: ListView.builder(
//                                 scrollDirection: Axis.horizontal,
//                                 padding: const EdgeInsets.only(left: 20, right: 8),
//                                 itemCount: state.featuredProperties.length,
//                                 itemBuilder: (context, index) {
//                                   return PropertyCard(
//                                     property: state.featuredProperties[index],
//                                     isFeatured: true,
//                                   );
//                                 },
//                               ),
//                             ),
                            
//                             const SizedBox(height: 24),
                            
//                             // New Offers Section
//                             Padding(
//                               padding: const EdgeInsets.symmetric(horizontal: 20),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   const Text(
//                                     'New offers',
//                                     style: TextStyle(
//                                       fontSize: 20,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                   ),
//                                   TextButton(
//                                     onPressed: () {
//                                       Navigator.pushNamed(context, AppRouter.popularScreen);
//                                     },
//                                     child: const Text(
//                                       'View all',
//                                       style: TextStyle(
//                                         color: Colors.black54,
//                                         fontSize: 14,
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
                            
//                             const SizedBox(height: 16),
                            
//                             // New Offers List
//                             ListView.builder(
//                               shrinkWrap: true,
//                               physics: const NeverScrollableScrollPhysics(),
//                               padding: const EdgeInsets.symmetric(horizontal: 20),
//                               itemCount: state.newOfferProperties.length,
//                               itemBuilder: (context, index) {
//                                 return PropertyCard(
//                                   property: state.newOfferProperties[index],
//                                   isHorizontal: false,
//                                 );
//                               },
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               );
//             }
            
//             // Loading or Error State
//             return const Center(
//               child: CircularProgressIndicator(),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../routes.dart';
import '../../logic/blocs/properties/properties_bloc.dart';
import '../../logic/blocs/properties/properties_state.dart';
import '../../logic/blocs/properties/properties_event.dart';
import '../widgets/search_bar.dart';
import '../widgets/property_card.dart';

class CatalogScreen extends StatelessWidget {
  const CatalogScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEEF5B1),
      body: SafeArea(
        child: BlocBuilder<PropertiesBloc, PropertiesState>(
          builder: (context, state) {
  if (state is PropertiesInitial) {
    // Dispatch events to load properties
    context.read<PropertiesBloc>().add(LoadFeaturedProperties());
    context.read<PropertiesBloc>().add(LoadNewOfferProperties());
    context.read<PropertiesBloc>().add(LoadPopularRentProperties());
    return const Center(child: CircularProgressIndicator());
  } else if (state is PropertiesLoading) {
    return const Center(child: CircularProgressIndicator());
  } else if (state is PropertiesError) {
    // Add error handling with a retry button
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text("Error: ${state.message}"),
          ElevatedButton(
            onPressed: () {
              context.read<PropertiesBloc>().add(LoadFeaturedProperties());
              context.read<PropertiesBloc>().add(LoadNewOfferProperties());
              context.read<PropertiesBloc>().add(LoadPopularRentProperties());
            },
            child: const Text("Retry"),
          ),
        ],
      ),
    );
  } else if (state is PropertiesLoaded) {
              return Column(
                children: [
                  const SizedBox(height: 16),
                  
                  // App Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            // Open drawer or menu
                          },
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.8),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.menu,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        const Row(
                          children: [
                            Text(
                              'Hi, Stanislav',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(width: 12),
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.grey,
                              child: Text(
                                'S',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Search Bar
                  const CustomSearchBar(),
                  
                  const SizedBox(height: 24),
                  
                  // Content
                  Expanded(
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(32),
                          topRight: Radius.circular(32),
                        ),
                      ),
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.only(top: 24, bottom: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Featured Section
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Featured',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pushNamed(context, AppRouter.popularScreen);
                                    },
                                    child: const Text(
                                      'View all',
                                      style: TextStyle(
                                        color: Colors.black54,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            const SizedBox(height: 16),
                            
                            // Featured Properties List
                            SizedBox(
                              height: 250,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                padding: const EdgeInsets.only(left: 20, right: 8),
                                itemCount: state.featuredProperties.length,
                                itemBuilder: (context, index) {
                                  return PropertyCard(
                                    property: state.featuredProperties[index],
                                    isFeatured: true,
                                  );
                                },
                              ),
                            ),
                            
                            const SizedBox(height: 24),
                            
                            // New Offers Section
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'New offers',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pushNamed(context, AppRouter.popularScreen);
                                    },
                                    child: const Text(
                                      'View all',
                                      style: TextStyle(
                                        color: Colors.black54,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            const SizedBox(height: 16),
                            
                            // New Offers List
                            ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              itemCount: state.newOfferProperties.length,
                              itemBuilder: (context, index) {
                                return PropertyCard(
                                  property: state.newOfferProperties[index],
                                  isHorizontal: false,
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            }
            
            // Loading or Error State
            return const Center(child: Text("Something went wrong"));
          },
        ),
      ),
    );
  }
}